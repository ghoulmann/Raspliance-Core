hosts_file=Plik z&nbsp;nazwami i&nbsp;adresami host�w <tt>hosts</tt>,0
