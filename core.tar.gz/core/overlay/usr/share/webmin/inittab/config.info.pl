inittab_file=�cie�ka do pliku inittab,0
